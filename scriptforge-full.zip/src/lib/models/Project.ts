import mongoose, { Schema, type Document } from 'mongoose';

export interface IScoreEntry {
  titleScore: number;
  descriptionScore: number;
  tagsScore: number;
  nicheFit: number;
  trendScore: number;
  engagementScore: number;
  seoScore: number;
  overallScore: number;
  tip: string;
  scoredAt: number;
}

export interface IProject extends Document {
  userId: mongoose.Types.ObjectId;
  title: string;
  topic: string;
  description: string;
  thumbnailPrompt: string;
  tags: string[];
  settings: {
    duration: string;
    theme: string;
    language: string;
    writingStyle: string;
    targetAudience: string;
  };
  status: 'draft' | 'generating' | 'completed' | 'error';
  scoreHistory: IScoreEntry[];
  createdAt: Date;
  updatedAt: Date;
}

const ProjectSchema = new Schema<IProject>(
  {
    userId: { type: Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    title: { type: String, required: true, trim: true, maxlength: 200 },
    topic: { type: String, required: true, trim: true, maxlength: 500 },
    description: { type: String, default: '', trim: true, maxlength: 2000 },
    thumbnailPrompt: { type: String, default: '', trim: true, maxlength: 2000 },
    tags: { type: [String], default: [] },
    settings: {
      duration: { type: String, default: 'medium' },
      theme: { type: String, default: 'cinematic' },
      language: { type: String, default: 'english' },
      writingStyle: { type: String, default: 'conversational' },
      targetAudience: { type: String, default: 'general' },
      sceneLength: { type: Number, default: 8 },
      totalScenes: { type: Number, default: 60 },
      scenesPerPhase: { type: Number, default: 10 },
    },
    status: { type: String, enum: ['draft', 'generating', 'completed', 'error'], default: 'draft' },
    scoreHistory: [{
      titleScore: Number,
      descriptionScore: Number,
      tagsScore: Number,
      nicheFit: Number,
      trendScore: Number,
      engagementScore: Number,
      seoScore: Number,
      overallScore: Number,
      tip: String,
      scoredAt: Number,
    }],
  },
  { timestamps: true }
);

ProjectSchema.index({ userId: 1, updatedAt: -1 });

export const ProjectModel =
  (mongoose.models.Project as mongoose.Model<IProject>) ??
  mongoose.model<IProject>('Project', ProjectSchema);