'use client';

import React, { useEffect } from 'react';
import { useRouter, usePathname } from 'next/navigation';
import { ThemeProvider, useTheme } from 'next-themes';
import { cn } from '@/lib/utils';
import { useAppStore } from '@/lib/store';
import { useAuthStore } from '@/lib/auth-store';
import { useIsMobile } from '@/hooks/use-mobile';
import AppSidebar from '@/components/layout/AppSidebar';
import AppHeader from '@/components/layout/AppHeader';
import { Toaster } from '@/components/ui/sonner';

// Sync saved theme from localStorage to next-themes on mount,
// and keep localStorage in sync when theme changes externally (e.g. header toggle)
function ThemeSync() {
  const { setTheme, theme } = useTheme();
  useEffect(() => {
    // On mount: read from localStorage → apply to next-themes
    try {
      const raw = localStorage.getItem('scriptforge_settings');
      if (raw) {
        const { theme: savedTheme } = JSON.parse(raw);
        if (savedTheme && ['light', 'dark', 'system'].includes(savedTheme)) {
          setTheme(savedTheme);
        }
      }
    } catch {}
  }, [setTheme]);

  // Keep localStorage in sync whenever next-themes changes
  useEffect(() => {
    if (!theme) return;
    try {
      const raw = localStorage.getItem('scriptforge_settings');
      const parsed = raw ? JSON.parse(raw) : {};
      if (parsed.theme !== theme) {
        parsed.theme = theme;
        localStorage.setItem('scriptforge_settings', JSON.stringify(parsed));
      }
    } catch {}
  }, [theme]);

  return null;
}

export default function AppLayout({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const pathname = usePathname();
  const { user, checked, checkSession } = useAuthStore();
  const loadProjects = useAppStore((s) => s.loadProjects);
  const loadTools = useAppStore((s) => s.loadTools);
  const sidebarCollapsed = useAppStore((s) => s.sidebarCollapsed);
  const isMobile = useIsMobile();

  useEffect(() => {
    checkSession();
  }, [checkSession]);

  useEffect(() => {
    if (checked && !user) {
      router.push('/');
    }
  }, [checked, user, router]);

  useEffect(() => {
    if (user) {
      loadProjects();
      loadTools();
    }
  }, [user, loadProjects, loadTools]);

  // Hide header on editor pages
  const isEditor = pathname.startsWith('/project/');

  if (!checked) {
    return <div style={{ padding: 40, fontFamily: 'sans-serif' }}>Loading...</div>;
  }

  if (!user) {
    return null;
  }

  return (
    <ThemeProvider
      attribute="class"
      defaultTheme="system"
      enableSystem
      disableTransitionOnChange
    >
      <div className="relative min-h-screen">
        <ThemeSync />
        <AppSidebar />

        <div
          className={cn(
            'flex min-h-screen flex-col',
            'transition-[margin-left] duration-300 ease-[cubic-bezier(0.4,0,0.2,1)]',
            isMobile && 'pb-20',
            !isMobile && (sidebarCollapsed ? 'md:ml-[68px]' : 'md:ml-[256px]')
          )}
        >
          {!isEditor && <AppHeader />}
          <main className="flex-1 p-4 md:p-6">
            {children}
          </main>
        </div>

        <Toaster position="bottom-right" richColors />
      </div>
    </ThemeProvider>
  );
}